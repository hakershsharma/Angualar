
    function getClickNumber() {
        
        var num = document.getElementById('lbl');
        var Click;
        if (num.innerText == '') {
            Click = 1;
        }
        else {
            Click = parseInt(num.innerText) + 1;
        }
        num.innerText = Click;
    }
